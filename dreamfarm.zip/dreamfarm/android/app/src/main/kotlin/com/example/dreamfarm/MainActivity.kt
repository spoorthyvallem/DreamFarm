package com.example.dreamfarm

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
